from flask import Flask, render_template, request, redirect, url_for, session, send_file
from flask_sqlalchemy import SQLAlchemy
import sqlite3
import bcrypt
import csv
import time
import secrets
import string

timestr = time.strftime("%Y%m%d-%H%M%S")

# App Initialization
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///../data.db"
app.config["SECRET_KEY"] = "your_secret_key_here"

db = SQLAlchemy(app)

# Model for Password Manager
class PasswordManager(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(520), nullable=False)
    site_url = db.Column(db.String(520), nullable=False)
    site_password = db.Column(db.String(520), nullable=False)

def init_master_db():
    conn = sqlite3.connect('master_password.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS master_passwords (
            id INTEGER PRIMARY KEY,
            salt TEXT NOT NULL,
            hash TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def store_master_password(password):
    conn = sqlite3.connect('master_password.db')
    cursor = conn.cursor()
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode(), salt)
    cursor.execute("DELETE FROM master_passwords")  # Clear old password
    cursor.execute("INSERT INTO master_passwords (salt, hash) VALUES (?, ?)", (salt.decode(), hashed_password.decode()))
    conn.commit()
    conn.close()

def get_master_password():
    conn = sqlite3.connect('master_password.db')
    cursor = conn.cursor()
    cursor.execute("SELECT salt, hash FROM master_passwords LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    return row if row else (None, None)

def verify_master_password(input_password):
    stored_salt, stored_hash = get_master_password()
    if not stored_hash:
        return False
    return bcrypt.checkpw(input_password.encode(), stored_hash.encode())

def lock_database():
    """Locks the encrypted database by resetting the key."""
    conn = sqlite3.connect("data.db")
    cursor = conn.cursor()
    cursor.execute("PRAGMA key='';")  # Lock the database
    conn.commit()
    conn.close()

@app.route('/')
def index():    
    return render_template("index.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        entered_password = request.form['master-password']
        if verify_master_password(entered_password):
            session["authenticated"] = True
            session["password"] = entered_password
            return redirect(url_for('pass_manager'))
        else:
            return render_template("login.html", error="Incorrect master password. Try again.")
    return render_template("login.html")

@app.route('/logout')
def logout():
    lock_database()  # Encrypt the database on logout
    session.pop("authenticated", None)
    session.pop("password", None)
    return redirect(url_for("login"))

@app.route('/pass_manager')
def pass_manager():
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    passwordlist = PasswordManager.query.all()
    return render_template("pass_manager.html", passwordlist=passwordlist)

@app.route("/add", methods=["GET", "POST"])
def add_details():
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    if request.method == "POST":
        email = request.form["email"]
        site_url = request.form["site_url"]
        site_password = request.form["site_password"]
        new_password_details = PasswordManager(email=email, site_url=site_url, site_password=site_password)
        db.session.add(new_password_details)
        db.session.commit()
        return redirect("/pass_manager")

@app.route("/update/<int:id>", methods=["GET", "POST"])
def update_details(id):
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    updated_details = PasswordManager.query.get_or_404(id)
    if request.method == "POST":
        updated_details.email = request.form["email"]
        updated_details.site_url = request.form["site_url"]
        updated_details.site_password = request.form["site_password"]
        db.session.commit()
        return redirect("/pass_manager")
    return render_template("update.html", updated_details=updated_details)

@app.route("/delete/<int:id>")
def delete_details(id):
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    new_details_to_delete = PasswordManager.query.get_or_404(id)
    db.session.delete(new_details_to_delete)
    db.session.commit()
    return redirect("/pass_manager")

@app.route("/export")
def export_data():
    if not session.get("authenticated"):
        return redirect(url_for("login"))
    with open('dump.csv', 'w') as f:
        out = csv.writer(f)
        out.writerow(['id', 'email', 'site_url', 'site_password'])
        data = PasswordManager.query.all()
        if data:
            for item in data:
                out.writerow([item.id, item.email, item.site_url, item.site_password])
            f.flush()
        else:
            return "No data to export"
    return send_file('dump.csv', mimetype='text/csv', download_name=f"Export_Password_{timestr}.csv", as_attachment=True)

@app.route('/pass_generator', methods=['GET', 'POST'])
def pass_generator():
    return render_template("pass_generator.html")

@app.route('/pass_strength_check')
def password_strength_checker():
    return render_template('pass_strength_check.html')

@app.route('/settings')
def settings():
    return render_template('settings.html')

@app.route('/change_master_password', methods=['POST'])
def change_master_password():
    if not session.get("authenticated"):
        return redirect(url_for("login"))

    old_password = request.form['old-master-password']
    new_password = request.form['new-master-password']
    confirm_password = request.form['confirm-new-master-password']

    # Get stored master password hash
    stored_salt, stored_hash = get_master_password()

    # Validate old master password
    if not stored_hash or not bcrypt.checkpw(old_password.encode(), stored_hash.encode()):
        return render_template("settings.html", error="Incorrect old master password.")

    # Ensure new passwords match
    if new_password != confirm_password:
        return render_template("settings.html", error="New passwords do not match.")

    # Store new master password
    store_master_password(new_password)

    # Log out user
    session.pop("authenticated", None)
    session.pop("password", None)

    return redirect(url_for("login"))


if __name__ == '__main__':
    init_master_db()
    with app.app_context():
        db.create_all()
    app.run(debug=True)