from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    encrypted_password = db.Column(db.String(255), nullable=False)

    def __init__(self, email, password):
        self.email = email
        self.encrypted_password = generate_password_hash(password)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    content = db.Column(db.Text, nullable=False)

    def __init__(self, user_id, content):
        self.user_id = user_id
        self.content = content

class ChangePasswordForm:
    password = db.Column(db.String(100), nullable=False)
